function setup() {
  createCanvas(400, 400);
}

let xJogador1 = 0;
let xJogador2 = 0;

function draw() {
  background('rgb(114,50,126)');
  textSize(40);
  text("💩", xJogador1, 100); // emoji de coco sorrindo
  text("🎅", xJogador2, 300); // emoji de papai noel
  rect(350, 0, 10, 400,);
  xJogador1 += random(5)
  xJogador2 += random(5)
}

function keyReleased() {
  if (key === 'b') {
   xJogador1 += random(5);
    // Código para correr
  }
}